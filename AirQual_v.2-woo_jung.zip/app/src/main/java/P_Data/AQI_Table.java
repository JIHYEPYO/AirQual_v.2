package P_Data;

/**
 * Created by user on 2016-08-08.
 */
public class AQI_Table {

    public String name;


}

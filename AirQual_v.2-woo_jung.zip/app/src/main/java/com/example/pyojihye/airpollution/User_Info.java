package com.example.pyojihye.airpollution;

/**
 * Created by PYOJIHYE on 2016-08-09.
 */
public class User_Info {
    public static String UdooName;
    public static String UdooMac;

    public static String HRName;
    public static String HRMac;

    public static String val;
}
